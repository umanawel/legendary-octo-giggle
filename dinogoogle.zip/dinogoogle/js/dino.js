//Instituto Naacional de Aprendizaje - Costa Rica
// Juego Mirkwood Robin
//Nicole Rodrigez Diaz
//Carlos Alfaro Camacho
//Welfran Grijalba Umaña



//Declaracion de variables de Canvas de juego
let board;
let boardWidth=800;
let boardHeight=400;
let context;
let myReq ;
const resetBtn = document.getElementById("reset");
const pauseBtn = document.getElementById("pause");
//Declaracion de variables de archivos de sonido
//Sonido de fondo
const gameAudio = new Audio("./sound/fondo.mp3");
gameAudio.loop = true;  // Loop the audio
//Sonido brinco
const brinco = new Audio("./sound/brinca.mp3");
//Sonido colision
const muerte = new Audio("./sound/muerte.m4a");
//Sonido estrella puntos extra
const estrella = new Audio("./sound/estrella.wav");
//Sonido botellita, que es una vida
const vidaSonido = new Audio("./sound/vida.wav");
//Robin, personaje principal 
//Dimensiones
let dinoWidth=100;
let dinoHeight=100;
//Posiciom
let dinoX=50;
let dinoY=boardHeight-dinoHeight;
//Declaracion de la imagen
let dinoImg;
let rotulo;

let dino ={
    x : dinoX,
    y : dinoY,
    width : dinoWidth,
    height : dinoHeight
}

let mensaje = new Image();


//Definicion de los obstaculos
let cactusArray =[];
let cactus1Width= 100;
let cactus2Width= 100;
let cactus3Width= 100;
let cactus1Height=100;
let cactus2Height=100;
let cactus3Height=100;
//Posicion de los obstaculos
let cactusX =900;
let cactusY =boardHeight-cactus1Height;

//Declaracion de las imagenes

let snack1Img;
let snack2Img;

let cactus1Img;
let cactus2Img;
let cactus3Img;

//Declaracion de las variables para los snacks
let snacksArray =[];
let snack1Width= 82;
let snack2Width= 81;

let snack1Height=79;
let snack2Height=85;

//Posicion de los obstaculos
let snackX =900;
let snackY =200;




//Declaracion de Variables fisicas del juego
let velocityX=-8;//Velocidad de avance de los cactus
let velocityY=0; // Velocidad de los brincos, el valor de 0 indica que est[a en el piso
let gameOver=false;
let score=0;
let gravity=.4  ;
let vidas=3;
let isPaused = false;
let isJumping = false; // Variable para controlar el estado de salto


window.onload = function inicio() {
        // Mostrar el modal al inicio
        const modal = document.getElementById("modal");
        modal.style.display = "block";
    
        // Evento para iniciar el juego al presionar el botón
        const startButton = document.getElementById("startButton");
        startButton.addEventListener("click", function() {
            modal.style.display = "none"; // Ocultar el modal al iniciar el juego
            iniciarJuego(); // Llamar la función que inicia el juego
        });
    
        // Resto de tu código de inicialización (carga de imágenes, eventos, etc.)
        // ...
   
}
function iniciarJuego() {
    gameAudio.play();
    
    board = document.getElementById("board");
    board.height = boardHeight;
    board.width = boardWidth;
    board.style = "background: url(/img/fondo.png)";
    context = board.getContext("2d");

    // Carga de las imágenes del dinosaurio
    dinoImg = new Image();
    dinoImg.src = "./img/robin-run.gif";
    
    // Carga de las imágenes de los obstáculos
    cactus1Img = new Image();
    cactus1Img.src = "./img/obs1.png";
    cactus2Img = new Image();
    cactus2Img.src = "./img/obs2.png";
    cactus3Img = new Image();
    cactus3Img.src = "./img/obs3.png";
    
    // Carga de las imágenes de los snacks
    snack1Img = new Image();
    snack1Img.src = "./img/estrella.png";
    snack2Img = new Image();
    snack2Img.src = "./img/vida.png";

    vidasDino = new Image(); 
    vidasDino.src = "./img/vida_1.png";  
    vidasDino.width = 30;
    vidasDino.height = 25;

    rotulo = new Image();
    rotulo.width=356;
    rotulo.height=250;
    rotulo.src='./img/gameover.png';
    dinoImg.onload = function() {
        context.drawImage(dinoImg, dino.x, dino.y, dino.width, dino.height);
    };
    dinoImg.src = './img/robin-run.gif'; 

    myReq=requestAnimationFrame(update);   
    setInterval(placeCactus, 1000);
    setInterval(placeSnacks, 1000);
    document.addEventListener("keydown", moveDino);
}
//Esta es la funcion que se llama cada vez que se refresca el loop que conforma el juego
//Esta funcion es la que dibuja todos los objetos y sus respectivos assets que conforman 
//el juego
function update() {
    if (!gameOver) {
       myReq= requestAnimationFrame(update);
        context.clearRect(0, 0, boardWidth, boardHeight);
        velocityY += gravity;

             dino.y = Math.min(dino.y + velocityY, dinoY);
     
          // Verificar si el dino ha aterrizado
          if (dino.y >= dinoY) {
            dino.y = dinoY; // Asegurarse de que el dino esté en el suelo
            isJumping = false; // Marcar que el dino no está saltando
            dinoImg.src = "./img/robin-run.gif"; // Cambiar la imagen a la de correr
        }
        context.drawImage(dinoImg, dino.x, dino.y, dino.width, dino.height);
        
        context.fillStyle = "#F8E7BE";
        context.font = "30px Lemon Tuesday";
        context.fillText(" Score " + score, 10, 40);
        
        context.fillStyle = "#F8E7BE";
        context.font = "30px Lemon Tuesday";
        context.fillText(" X " + vidas, 675, 50);
        context.drawImage(vidasDino, 635, 28, vidasDino.width, vidasDino.height);

        // Refresca y dibuja los obstaculos
        for (let i = 0; i < cactusArray.length; i++) {
            cactusArray[i].x += velocityX;
            context.drawImage(cactusArray[i].img, cactusArray[i].x, cactusArray[i].y, cactusArray[i].width, cactusArray[i].height);
            
            if (detectCollision(dino, cactusArray[i])) {
                muerte.play();
                vidas--;
                if (vidas > 0) {
                    cactusArray = [];
                    placeCactus();
                    placeSnacks();
                } else {
                    context.clearRect(0, 0, boardWidth, boardHeight);
                    context.fillText(" X " + vidas, 675, 50);
                    context.fillText(" Score " + score, 320, 235);
                    context.drawImage(vidasDino, 635, 28, vidasDino.width, vidasDino.height);
                    gameOver = true;
                    dinoImg.src = "./img/dead1.png";
                    context.drawImage(dinoImg, 300, 200, dinoImg.width/4, dinoImg.height/2);
                    context.drawImage(rotulo, 200, 80, rotulo.width, rotulo.height);
                }
            } else {
                if(dino.x > cactusArray[i].x && cactusArray[i] && cactusArray[i].x + cactusArray[i].width < 0){
                    score += cactusArray[i].puntos;
                    cactusArray.splice(i,1);
                }
            }
        }

        // Refresca y dibuja los snacks
        for (let j = 0; j < snacksArray.length; j++) {
            snacksArray[j].x += velocityX;
            context.drawImage(snacksArray[j].img, snacksArray[j].x, snacksArray[j].y, snacksArray[j].width, snacksArray[j].height);
            
            if (detectCollision(dino, snacksArray[j])) {
                if (snacksArray[j].img == snack1Img) {
                    score += snacksArray[j].puntos;
                    estrella.play();
                } else {
                   vidas += snacksArray[j].puntos
                   vidaSonido.play();
                }
                snacksArray.splice(j, 1);
            }
        }
    }
}

function moveDino(e) {
    // Check if the game is already paused
    if (isPaused) {
        return; // If paused, don't allow the dinosaur to jump or pause further
    }

    // Check if the game is over
    if (gameOver) {
        context.clearRect(0, 0, boardWidth, boardHeight);
        gameOver = true;
        context.fillText(" X " + vidas, 675, 50);
        context.fillText(" Score " + score, 320, 235);
        context.drawImage(rotulo, 200, 80, rotulo.width, rotulo.height);
        return;
    }

    // Check if the space bar is pressed and the dinosaur is allowed to jump
    if ((e.code == "Space" || e.code == "ArrowUp") && dino.y > 200) {
        // Command to jump
        isJumping = true; // Mark that the dino is jumping
        velocityY = -13;
        dinoImg.src = "./img/jump.png";
        brinco.play();

        // Resume the game after the jump if paused
        if (isPaused) {
            togglePause(); // Resume the game
        }
    }
}
//Funcion para cargar los obstaculos en memoria en un arreglo
function placeCactus() {
    let cactus = {
        img: null,
        x: cactusX,
        y: cactusY,
        width: null,
        height: cactus1Height,
        puntos: null
    };

    let cactusChance = Math.random();
    if (cactusChance > .9) {
        cactus.img = cactus3Img;
        cactus.width = cactus3Width;
        cactus.puntos = 10;
        cactusArray.push(cactus);
    }
    else if (cactusChance > .7) {
        cactus.img = cactus2Img;
        cactus.width = cactus2Width;
        cactus.puntos = 5;
        cactusArray.push(cactus);
    } else if (cactusChance > .5) {
        cactus.img = cactus1Img;
        cactus.width = cactus1Width;
        cactus.puntos = 2;
        cactusArray.push(cactus);
    }
    if (cactusArray.length > 5) {
        cactusArray.shift(); // Limpia la primer entrada del arreglo, para mantener solo 5 cactus en memoria
    }
}
//Funcion para detectar colsiones entre objetos. Retorna un valor booleano
function detectCollision(a, b) {
    return a.x < b.x + b.width &&    // esquina superior izquierda de a no toca esquina superior derecha de b
           a.x + a.width > b.x &&    // esquina superior derecha de a sobrepasa  esquina superior izquierda de b
           a.y < b.y + b.height &&   // esquina superior izquierda de a no toca esquina inferior izquierda de b
           a.y + a.height > b.y;     // esquina inferior izquierda de a sobrepasa esquina superior izquierda de b
}
//Funcion para cargar los snacks en memoria en un arreglo
function placeSnacks() {
    let snack = {
        img: null,
        x: snackX,
        y: randomNumber(75,175), // Set y position randomly above the height of the dinosaur
        width: null,
        height: snack1Height,
        puntos: null
    };

    let snacksChance = Math.random();
    if (snacksChance > .9) {
        snack.img = snack2Img;
        snack.width = snack2Width;
        snack.puntos = 1;
        snacksArray.push(snack);
    }
    else if (snacksChance > .7) {
        snack.img = snack1Img;
        snack.width = snack1Width;
        snack.puntos = 5;
        snacksArray.push(snack);
    } 
    if (snacksArray.length > 5) {
        snacksArray.shift(); // Limpia la primer entrada del arreglo, para mantener solo 5 cactus en memoria
    }
}
function randomNumber(min, max) {
    return Math.random() * (max - min) + min;
}

//Funcion para pausar el juego
//Para el animation frame, partiendo de una variable donde el [ultimo se guardo]
function togglePause() {

    isPaused = !isPaused;
    if (isPaused) {
        gameAudio.pause();
        cancelAnimationFrame(myReq); // Cancela el animation frame
    } else {
        gameAudio.play();
        if (!gameOver) {
            myReq=requestAnimationFrame(update); // Prosigue el game loop only si el juego no ha terminado
        }
    }
}
//Event Listener para los botones de pausa y de reiniciar
resetBtn.addEventListener("click", resetTablero);
pauseBtn.addEventListener("click",togglePause);

//Funcio para resetear el tablero 

function resetTablero() {
    location.reload();
}
